/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos.application;

import java.util.ArrayList;

/**
 *
 * @author chris
 */
public class Transaksi {
   String kode;
   String nama;
   String totalBelanja;
   String jumlahDibayar;
   String kembalian;
   String tanggal;
   
   
   
}
